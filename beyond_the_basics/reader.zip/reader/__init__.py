# to avoid reader.reader.Reader and to have reader.Reader

from reader.reader import Reader